# Linguist Module Versions

## 1.0 (2018-02-23)
#### [Definition](./TBX_linguist_module_1.0/Linguist Module Definition.pdf)
#### [Download](./TBX_linguist_module_1.0.zip)
