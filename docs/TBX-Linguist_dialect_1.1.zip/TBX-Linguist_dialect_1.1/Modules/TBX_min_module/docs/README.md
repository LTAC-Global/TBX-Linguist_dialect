# Min Module Versions

## 1.0 (2018-05-01)
#### [Definition](https://ltac-global.github.io/TBX_min_module/TBX_min_module_1.0/Min%20Module%20Definition.pdf)
#### [Download](https://ltac-global.github.io/TBX_min_module/TBX_min_module_1.0.zip)
